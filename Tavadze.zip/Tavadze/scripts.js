document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('news-list')) {
      fetchNews();
    }
  
    if (document.getElementById('create-news-form')) {
      document.getElementById('create-news-form').addEventListener('submit', handleCreateNews);
    }
  });
  
  async function fetchNews() {
    try {
      const response = await fetch('https://btu-exam-cb6c3fdf3b9d.herokuapp.com/news');
      const news = await response.json();
      const newsList = document.getElementById('news-list');
  
      news.forEach(item => {
        const newsItem = document.createElement('div');
        newsItem.className = 'news-item';
        newsItem.innerHTML = `
          <div class="news-content">
            <h2>${item.title}</h2>
            <p>Category: ${item.category}</p>
            <p>Likes: ${item.likes}</p>
          </div>
          <div class="news-actions">
            <button class="delete-btn" onclick="deleteNews(${item.id}, this)">Delete</button>
          </div>
        `;
        newsList.appendChild(newsItem);
      });
    } catch (error) {
      console.error('Error fetching news:', error);
    }
  }
  
  async function deleteNews(id, button) {
    try {
      await fetch(`https://btu-exam-cb6c3fdf3b9d.herokuapp.com/news/${id}`, { method: 'DELETE' });
      const newsItem = button.closest('.news-item');
      newsItem.classList.add('fade-out');
      setTimeout(() => {
        newsItem.remove();
      }, 500);
    } catch (error) {
      console.error('Error deleting news:', error);
    }
  }
  
  async function handleCreateNews(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData);
  
    if (!data.title || !data.description || !data.category) {
      alert('Please fill in all required fields');
      return;
    }
  
    try {
      await fetch('https://btu-exam-cb6c3fdf3b9d.herokuapp.com/news', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
      window.location.href = 'index.html';
    } catch (error) {
      console.error('Error creating news:', error);
    }
  }
  